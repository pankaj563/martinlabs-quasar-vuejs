<template>
  <q-layout>
    <!--
      Replace following "div" with
      "<router-view class="layout-view">" component
      if using subRoutes
    -->
    <div class="layout-view">
      <!--/// HEADER SECTION -->
<div class="header-section">
  <!--/// INNNER SECTION -->
  <!--/// HEADER TOP SECTION -->
  <div class="header-top-section-main  container-fluid animatedParent">
  <div class="container">


    <div class="row header-top-section"> 
      <!--/// LOGO SECTION -->
      <div class="col-sm-4 col-md-4 col-lg-4 col-xs-6 col-xl-12 logo-section animated growIn">
         <img src="../assets/logo.png" />
      </div>
      <!--/// LOGO SECTION END -->
      <!--/// MENU SECTION -->
      <div class="col-sm-8 col-md-8 col-lg-8 col-xs-6 col-xl-12 menu-section navbar">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>
      <div class="collapse navbar-collapse" id="myNavbar">
         <ul class="nav navbar-nav">
            <li><a href="#">Home</a></li>
            <li><a href="#">Work</a></li>
            <li><a href="#">Get a Quote</a></li>
            <li><a href="#">Technologies</a></li>
            <li><a href="#">Contact</a></li>
         </ul>
      </div>
      </div>
      <!--/// MENU SECTION END -->
     </div>
  </div>
  </div>
  <!--/// HEADER TOP SECTION -->
    <!--/// HEADER BOTTOM SECTION -->
  <div class="header-bottom-section-main  container-fluid animatedParent">  
   <div class="container">
   

    <div class="row header-bottom-section animated bounceInLeft">
        <div class="col-sm-12 col-md-12 col-lg-12 col-xs-12 col-xl-12">
           <h2>APP DEVELOPMENT</h2>
           <h1> NATIVE APPS FOR iOS & Android</h1>
           <p>We develop native mobile apps, using XCode, Android Studio or Xamarin.</p>
           <a href="#" class="read-more-button">request a quote</a>
        </div>
    </div>

  </div>
  </div>
    <!--/// HEADER BOTTOM SECTION END -->  
  <!--/// INNER SECTION END -->

</div>
<!--/// HEADER SECTION END -->
<!--/// By Apptite Inovacoes Techologicas LTDA SAECTION -->
<div class="by-apptite-section container-fluid animatedParent">
   <div class="container">
      <!--// LEFT SECTION -->
      <div class="col-sm-6 col-md-6 col-lg-6 col-xs-12 col-xl-12 by-apptite-left-section animated bounceInLeft">
         <img src="../assets/by_apptite.png" />
         <h2>By Apptite Inovações Tecnologicas LTDA</h2>
         <p>Open iTunes to buy and download apps.</p>
         
         <hr />
         
         <h2>Description</h2>
         <p>Apptite is only available in São Paulo / SP.</p> 
         <p>Apptite is the first artisanal food marketplace in Brazil! </p>

          <a href="#" class="visit-us">Visit</a>
      
      </div>
      <!--/// LEFT SECTION END -->
      <!--// RIGHT SECTION -->
      <div class="col-sm-6 col-md-6 col-lg-6 col-xs-12 col-xl-12 by-apptite-right-section animated bounceInRight">
        <img src="../assets//mob1.png" />
      </div>
      <!--/// RIGHT SECTION END -->
   
   </div>

</div>
<!--/// By Apptite Inovacoes Techologicas LTDA END -->
<!--// Mapix - Transporte -->
<div class="mapix-section container-fluid animatedParent">
   <div class="container">
      <!--/// RIGHT PART -->
      <div class="col-sm-6 col-md-6 col-lg-6 col-xs-12 col-xl-12 mapix-section-right animated bounceInUp">
         <img src="../assets/icon.png" class="only-for-desktop" />
         <h1 class="inner-heading-1">Mapix - Transporte Escolar em suas mãos</h1>
         <h2 class="inner-heading-2">By Mapix</h2>
         <p>Open iTunes to buy and download apps.</p>
         <hr/>
         <h2 class="inner-heading-3">Description</h2>
         <p>Mapix é o aplicativo que vai mudar a forma de usar transporte escolar.</p>

<p>Integrando Passageiros, seus Responsáveis e Transportadores Escolares em um único App, Mapix oferece vantagens</p>
         <a href="#" class="visit-us">Visit</a>
      </div>
      <!--/// RIGHT PART END -->
      <!--// LEFT PART =-->
      <div class="col-sm-6 col-md-6 col-lg-6 col-xs-12 col-xl-12 mapix-section-left animated bounceInDown">
        <img src="../assets/mobile-2.png" />
      </div>
      <!--/// LEFT PART END -->
      
   </div>
</div>
<!--/// Mapix - Transporte  END -->
<!--/// Panorist Section -->
<div class="panorist-section container-fluid animatedParent">
   <div class="container">
      <!--// LEFT SECTION -->
      <div class="col-sm-6 col-md-6 col-lg-6 col-xs-12 col-xl-12 panorist-left-section animated bounceInDown">
          <h1 class="inner-heading-1"><img src="../assets/next-icon.png"/> panorist</h1>
         <h2 class="inner-heading-2">By  Panorist Tecnologicas LTDA</h2>
         <p>Open iTunes to buy and download apps.</p>
         
         <hr />
         
         <h2 class="inner-heading-3">Description</h2>
         <p>Apptite is only available in São Paulo / SP.</p> 
         <p>Apptite is the first artisanal food marketplace in Brazil! </p>

          <a href="#" class="visit-us">Visit</a>
      
      </div>
      <!--/// LEFT SECTION END -->
      <!--// RIGHT SECTION -->
      <div class="col-sm-6 col-md-6 col-lg-6 col-xs-12 col-xl-12 panorist-right-section animated bounceInRight">
        <img src="../assets/lap-mob.png" />
      
      </div>
      <!--/// RIGHT SECTION END -->
   
   </div>

</div>
<!--/// Panorist Section END -->
<!--// Meet & Drink -->
<div class="meet-drink-section container-fluid animatedParent">
   <div class="container">
   <div class="row">
    <!--/// RIGHT PART -->
      <div class="col-sm-6 col-md-6 col-lg-6 col-xs-12 col-xl-6 meet-drink-section-right animated bounceInUp">
        <img src="../assets/next-icon1.png" class="only-for-desktop" />
         <h1 class="inner-heading-1">Meet & Drink</h1>
         <h2 class="inner-heading-2">From Martin Development Systems Ltd.
</h2>
         <p>Open iTunes to buy and download apps.</p>
         <hr/>
         <h2 class="inner-heading-3">Description</h2>
         <p>Meet the new application that will transform how you 
will enjoy your nights and friendships!</p>

<p>Where is everybody? Find out where the people are! </p>
         <a href="#" class="visit-us">Visit</a>
      </div>
      <!--/// RIGHT PART END -->
      <!--// LEFT PART =-->
      <div class="col-sm-6 col-md-6 col-lg-6 col-xs-12 col-xl-12 meet-drink-section-left animated bounceInDown">
        <img src="../assets/next-phone.png" />
      </div>
      <!--/// LEFT PART END -->
     
     </div> 
      
   </div>
</div>
<!--/// Meet & Drink -->
<!--// MARTINLABS SECTION -->
<div class="martinlabs-section container-fluid animatedParent">
   <div class="container">
    <div class="row martinlabs-section-top animated fadeInDown">
      <h1 class="heading-section">MARTINLABS</h1>
      <p>The Martinlabs exists with the purpose of develop quality applications that are both useful and functional. We work with agencies, companies and startups, developing original, innovative content.</p>
    </div>
    <div class="row martinlabs-section-bottom animated growIn">
       <!--// LEFT PART -->
       <div class="col-sm-6 col-md-6 col-lg-6 col-xs-12 col-xl-6 martinlabs-left-section">
         <img src="../assets/curcle.png" />
       
       </div>
       <!--/// LEFT PART END -->
       <!--// RIGHT PART -->
       <div class="col-sm-6 col-md-6 col-lg-6 col-xs-12 col-xl-6 martinlabs-right-section">
          <ul>
             <li>
                <h1>Why we do what we do</h1>
                <p>Martinlabs wants to build systems. Our desire is to build applications to create and enhance the experience of life.</p>
             </li>
             <li>
                <h1>Focus On User</h1>
                <p>The user is the most important part of a software system, and trying to understand them must be priority.</p>
             </li>
             <li>
                <h1>Software engineering</h1>
                <p>We are a software development company. We project our systems before we build them.</p>
             </li>
          </ul>
           <a href="#" class="request-a-quote">request a quote</a>
       
       
       </div>
       <!--/// RIGHT PART END -->
    
    </div>   
      
      
   </div>
</div>
<!--/// MARTINLABS Section END -->
<!--// Technologies -->
<div class="technologies-section container-fluid animatedParent">
   <div class="container">
     <div class="row">
      <h1 class="heading-section animated bounceIn">Technologies</h1>
     <!--/// LEFT PART -->
     <div class="technologies-section-left col-sm-4 col-md-4 col-lg-4 col-xs-12 col-xl-4 animated fadeInLeft">
        <ul>
           <li class="ios-icon">
             <h1>iOS</h1>
             <p>iOS native applications with all resources and the best performance.</p>
           </li>
            <li class="android-icon">
             <h1>Android</h1>
             <p>Android native applicartions, high performance, ready for screens of any size and density.</p>
           </li>
        </ul>
     
     
     </div>
     <!--// LEFT END -->
     <!--// MID SECTION -->
     <div class="technologies-section-mid col-sm-4 col-md-4 col-lg-4 col-xs-12 col-xl-4 animated bounceInDown">
        <img src="../assets/trn-phone.png" />
     </div>
     <!--// MID SECTION END -->
     <div class="technologies-section-right col-sm-4 col-md-4 col-lg-4 col-xs-12 col-xl-4 animated fadeInRight">
     <ul>
           <li class="html-icon">
             <h1>HTML5 and Javascript</h1>
             <p>Solutions for Web applications using state-of-the standards for your mobile application, your Administrative Panel and Websites.</p>
           </li>
            <li class="amazon-web-services-icon">
             <h1>Amazon Web Services</h1>
             <p>Servers at Amazon assure stability and growth with lowest cost and easy to evolve.</p>
           </li>
        </ul>
     
     </div>
     <!--/// RIGHT SECTION -->
      </div>
     <!--// RIGHT SECTION END -->
   </div>
</div>
<!--/// Technologies END -->
<!--// FOOTER SECTION -->
<!--/// FOOTER SECTION -->
<div class="footer-section container-fluid animatedParent">
   <div class="container">
      <div class="row">
         <h1 class="heading-section animated swing">Contact</h1>
          <!--/// LEFT PART -->
          <div class="col-sm-4 col-md-4 col-lg-4 col-xs-12 col-xl-4 footer-left animated lightSpeedInLeft">
             <ul>
              <li> Rua Teodoro Sampaio, 744
Pinheiros, São Paulo, SP </li>
              <li>+1 650 2784426</li>
              <li>atendimento@martinlabs.com.br</li>
             
             </ul>
          
          </div>
          <!--/// LEFT PART END -->
          <!--/// MID SECTION =-->
          <div class="col-sm-4 col-md-4 col-lg-4 col-xs-12 col-xl-4 footer-mid animated tada">
             <ul>
                <li>Adam Back</li>
                <li>adam back@info.com</li>
                <li>149-88-36</li>
                <li>Lrome dummy text</li>
             
             </ul>
          
              <a href="#" class="footer-submit-button">Submit</a>
          
          </div>
          <!--/// MID SECTION END-->
          <!--/// RIGHT SECTION -->
          <div class="col-sm-4 col-md-4 col-lg-4 col-xs-12 col-xl-4 footer-right animated lightSpeedInRight">
             <ul>
                <li><i class="fa fa-home" aria-hidden="true"></i><a href="#">Home</a></li> 
                <li><img src="../assets/work.png" /><a href="#">Work </a></li> 
                <li><i class="fa fa-phone" aria-hidden="true"></i><a href="#">Get a Quote </a></li> 
                <li><img src="../assets/technology.png" /><a href="#">Technologies </a></li> 
                <li><i class="fa fa-at" aria-hidden="true"></i><a href="#">Contact</a></li> 
             </ul>
          
          
          </div>
          <!--/// RIGHT SECTION END -->
      
      </div>
   </div>

</div>
<!--/// FOOTER SECTION  END -->
<!--/// COPYRIGNT SECTION -->
<div class="copyright-section container-fluid">
   <div class="container">
      <div class="row">
      <!--// LEFT -->
      <div class="col-sm-6 col-md-6 col-lg-6 col-xs-6 col-xl-6">
         <p>Powered By - <a href="#">iMark Infotech</a></p>
      </div>
      <!--// LEFT PART END -->
      <!--/// RIGHT PART -->
      <div class="col-sm-6 col-md-6 col-lg-6 col-xs-6 col-xl-6">
        <p>© 2017 martinlabs</p>
      </div>
      <!--// RIGHT PART END -->
      </div>
   </div>
</div>
<!--/// COPYRIGHT SECTION END -->
    </div> 
  </q-layout>
</template>
